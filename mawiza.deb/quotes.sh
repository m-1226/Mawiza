#!/bin/bash

# Set the default duration to 15 minutes
duration=15

# Set the default language to Arabic
language="arabic"

# Define the colors for the messages
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Define the function to start the script
start_script() {
  # Print a message to confirm the chosen duration
  echo -e "${YELLOW}Notifications will be displayed every $duration minutes.${NC}"

  # Set the quotes file path based on the chosen language
  quotes_file="$HOME/Desktop/quotes_script/${language}_quotes.json"

  # Check if the quotes file exists
  if [[ ! -f "$quotes_file" ]]; then
    echo -e "${RED}Error: The $language quotes file does not exist.${NC}" >&2
    exit 1
  fi

  # Set the icon file path
  icon_file="$HOME/Desktop/quotes_script/paper_quote.png"

  # Start the script
  while true; do
    quote=$(jq -r '.[].quote' "$quotes_file" | shuf -n 1)
    author=$(jq -r '.[].author' "$quotes_file" | shuf -n 1)
    notify-send -i "$icon_file"  "$author" "$quote"
    sleep "${duration}m"
  done
}

# Print a welcome message
echo -e "${YELLOW}Welcome to Mawiza!${NC}"

# Prompt the user to choose a language
echo -e "${YELLOW}Please choose a language:${NC}"

# Display the language options
echo -e "${YELLOW}a) Arabic${NC}"
echo -e "${YELLOW}e) English${NC}"

# Read the user's choice
read -p "Enter your choice (a/e): " choice

# Set the language based on the user's choice
case $choice in
  a)
    language="arabic"
    ;;
  e)
    language="english"
    ;;
  *)
    echo -e "${RED}Invalid choice: $choice${NC}" >&2
    exit 1
    ;;
esac

# Print a message to confirm the chosen language
echo -e "${YELLOW}You have chosen the $language language.${NC}"

# Prompt the user to enter the duration between notifications
while true; do
  read -p "Enter the duration between notifications in minutes (default is 15): " duration

  # Use the default duration if no input is given
  if [[ -z "$duration" ]]; then
    duration=15
    break
  fi

  # Check if the input is a valid number
  if [[ ! "$duration" =~ ^[0-9]+$ ]]; then
    echo -e "${RED}Error: Please enter a valid number.${NC}"
  else
    break
  fi
done

# Decide whether to run the script in the background
read -p "Do you want to run the script in the background? (y/n) " background

# If not running in the background, start the script in the foreground
if [[ "$background" =~ ^[Nn]$ ]]; then
  echo -e "${GREEN}Running the script in the foreground.${NC}"
  start_script
else
  echo -e "${GREEN}Running the script in the background.${NC}"
  start_script &
  pid=$! # Get the process ID of the background script
  echo -e "${YELLOW}To stop the script, run the following command: kill $pid${NC}"
fi
